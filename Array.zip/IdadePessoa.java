package array;

import java.util.Scanner;

public class IdadePessoa {
	
	//declara��o dos atributos
	protected String Nomes[];
	protected int Idades[];
	
	//declara��o do contrutor
	public IdadePessoa(int tamanho) {
		Nomes= new String[tamanho];
		Idades= new int[tamanho];
	}//fim contrutor
	
	public void Preenchimento() {
		Scanner input = new Scanner(System.in);
		for(int contador=0; contador < Idades.length; contador++) {
			System.out.print("Digite o nome:");
			Nomes[contador]= input.next();
			System.out.print("Digite a idade:");
			Idades[contador]= input.nextInt();
		
	}
  }
	public void MostraVetores() {
		for(int contador=0; contador < Idades.length; contador++) {
			System.out.println("Nome:"+Nomes[contador]+" possui "+Idades[contador]+" anos");
			}
	}
	public int QtdMaioresIdades() {
		int qtd=0;
		for(int contador=0; contador < Idades.length; contador++) {
			if(Idades[contador]>=18) {
				System.out.println(Nomes[contador]+" � maior de idade");
			}
		}
		return qtd;
	}
	
	public void NomesMaioresIdades() {
		for(int contador=0; contador < Idades.length; contador++) {
			if(Idades[contador]>=18) {
				System.out.println(Nomes[contador]+" � maior de idade");
			}
		}
		
	}
	
	public void PesquisarPorNome(String nome) {
		for(int contador=0; contador < Idades.length; contador++) {
			if(nome.equals(Nomes[contador])) {
				System.out.println(nome+" est� na posi��o: "+contador);
			}
        }
	}
	public void PesquisarPorIdade(int idade) {
		for(int contador=0; contador < Idades.length; contador++) {
			if(idade==Idades[contador]) {
				System.out.println(idade+" est� na posi��o: "+contador);
			}
		}
	}
}







