package array;

public class initArrayTeste {
	public static void main(String args[]) {
		//CRIAR OBJETO
		initArray4 obj= new initArray4();
		double recebeArray[];
		double recebeTotal;
		recebeArray= obj.PopulaVetor(6);
		recebeTotal= obj.Somatorio(recebeArray);
		System.out.println("\n********************");
		System.out.println("Resultado:"+recebeTotal);
		
	}

}
