package array;

import java.util.Scanner;
public class IdadePessoaTest {
	public static void main(String args[]) {
		IdadePessoa obj= new IdadePessoa(3);
		Scanner input= new Scanner(System.in) ;
		
		System.out.println("****INICIANDO PREENCHIMENTO DOS VETORES*****");
		obj.Preenchimento();
		System.out.println("****INICIANDO MOSTRAR VETORES*****");
		obj.MostraVetores();
		System.out.println("****INICIANDO QtdMaioresIdades*****");
		int qtdMaiorIdade= obj.QtdMaioresIdades();
		System.out.println("Existe"+ qtdMaiorIdade + " maiores de idade!!!");
		
		System.out.println("****INICIANDO NomesMaioresIdades*****");
		obj.NomesMaioresIdades();
		
		System.out.println("****INICIANDO PesquisarPorNome*****");
		System.out.println("Digite um nome para buscar: ");
		String nome= input.next();
		obj.PesquisarPorNome(nome);
		
		System.out.println("****INICIANDO PesquisarPorIdade*****");
		System.out.println("Digite uma idade para buscar: ");
		int idade= input.nextInt();
		obj.PesquisarPorIdade(idade);
	}

}
